package lexicalAnalyzer;

import tokens.LextantToken;
import tokens.Token;


public enum Keyword implements Lextant {
	STATIC("static"),
	CONST("const"),
	VAR("var"),
	PRINT("print"),
	NEWLINE("_n_"),
	TAB("_t_"),
	TRUE("_true_"),
	FALSE("_false_"),
	INT("int"),
	FLOAT("float"),
	STRING("string"),
	CHAR("char"),
	BOOL("bool"),
	RAT("rat"),
	VOID("void"),
	EXEC("exec"),
	IF("if"),
	ELSE("else"),
	WHILE("while"),
	FOR("for"),
	INDEX("index"),
	ELEM("elem"),
	OF("of"),
	RELEASE("release"),
	LENGTH("length"),
	NEW("new"),
	CLONE("clone"),
	REVERSE("reverse"),
	CONTINUE("continue"),
	BREAK("break"),
	FUNCTION("func"),
	RETURN("return"),
	CALL("call"),
	MAP("map"),
	ZIP("zip"),
	REDUCE("reduce"),
	FOLD("fold"),
	NULL_KEYWORD("");

	private String lexeme;
	private Token prototype;
	
	
	private Keyword(String lexeme) {
		this.lexeme = lexeme;
		this.prototype = LextantToken.make(null, lexeme, this);
	}
	public String getLexeme() {
		return lexeme;
	}
	public Token prototype() {
		return prototype;
	}
	
	public static Keyword forLexeme(String lexeme) {
		for(Keyword keyword: values()) {
			if(keyword.lexeme.equals(lexeme)) {
				return keyword;
			}
		}
		return NULL_KEYWORD;
	}
	public static boolean isAKeyword(String lexeme) {
		return forLexeme(lexeme) != NULL_KEYWORD;
	}
	
	/*   the following hashtable lookup can replace the serial-search implementation of forLexeme() above. It is faster but less clear. 
	private static LexemeMap<Keyword> lexemeToKeyword = new LexemeMap<Keyword>(values(), NULL_KEYWORD);
	public static Keyword forLexeme(String lexeme) {
		return lexemeToKeyword.forLexeme(lexeme);
	}
	*/
}
